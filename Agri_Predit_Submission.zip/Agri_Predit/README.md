# Agri Predit • Predictive Modeling for Agriculture Data Science Project

An end-to-end, industrial-grade Precision Agronomy Machine Learning system and interactive web application designed to recommend optimal crops based on 4 essential soil attributes (**Nitrogen, Phosphorus, Potassium, Soil pH**) and 3 environmental conditions (**Temperature, Relative Humidity, Rainfall**).

---

## 🌟 Project Highlights & Features

1. **State-of-the-Art Supervised Model**:
   - Built with an **Ensemble Random Forest Classifier** (100 Decision Trees).
   - Achieves **99.55% Test Accuracy** and **0.9955 Weighted F1-Score** on holdout test data (440 samples, 20% split).
   - 20 out of 22 crop classes achieved a perfect **100% Precision and Recall**.

2. **Full 7-Feature Multi-Attribute Analysis**:
   - `N`: Soil Nitrogen (0 – 140 kg/ha)
   - `P`: Soil Phosphorus (5 – 145 kg/ha)
   - `K`: Soil Potassium (5 – 205 kg/ha)
   - `ph`: Soil Reaction pH Scale (3.5 – 9.9)
   - `temperature`: Ambient Temperature (8 – 45 °C)
   - `humidity`: Relative Humidity (14 – 100 %)
   - `rainfall`: Precipitation (20 – 300 mm)

3. **Interactive & Aesthetic Glassmorphic Web Application**:
   - **Tab 1: Field Diagnostic & Radar Fingerprint**:
     - Visual **Litmus pH Scale** with real-time pointer tracking (Acidic / Neutral / Alkaline).
     - Atmospheric moisture meters for Humidity & Rainfall.
     - **Soil & Climate Fingerprint Radar Chart** (powered by Chart.js) comparing user inputs against crop scientific benchmarks.
     - Top 3 candidate crop confidence distributions.
     - Scientific benchmark evidence table explaining *why* the model selected that crop.
     - Quick preset buttons (`Flood Basin Rice`, `High-K Apple Orchard`, `Black Soil Cotton`, etc.).
   - **Tab 2: Model Evaluation & Metrics Graphs Dashboard**:
     - 4 High-impact KPI cards: Test Accuracy (99.55%), Weighted F1 (0.9955), Macro Precision (99.60%), Macro Recall (99.50%).
     - **Graph 1**: Random Forest Feature Importance Horizontal Bar Chart (Rainfall 23.2%, Humidity 22.1%, Potassium 17.3%, Phosphorus 15.1%, Nitrogen 10.5%, Temperature 6.9%, pH 4.9%).
     - **Graph 2**: Multi-Class Precision & Recall Grouped Bar Chart across representative crops.

---

## 🔬 Four Required Data Science Tasks

### Task 1: Data Cleaning & Preprocessing
- **Dataset**: 2,200 observations, 22 crops (100 samples per class).
- **Integrity Checks**:
  - Missing values: `0` (clean dataset).
  - Duplicates: `0`.
  - Negative values: `0` (all chemical concentrations and climate readings strictly physical).
- **Encoding & Benign Outlier Preservation**: Label encoded 22 targets into numerical classes; natural extreme nutrient demands (e.g. Apples and Grapes requiring >190 kg/ha Potassium) were retained without clipping to preserve crop separation boundaries.

### Task 2: Predictive Modeling Using Supervised ML
- Evaluated supervised classifiers on a 80-20 stratified train-test split:
  - **Random Forest Classifier**: **99.55% Test Accuracy** (Selected as the production model).
  - **XGBoost Classifier**: 98.86% Test Accuracy.
- **Confusion Matrix & Metrics**:
  - Total test samples: 440.
  - Correct predictions: 438 / 440 (Only 2 minor edge misclassifications: 1 jute sample classified as rice due to saturated monsoon conditions, and 1 muskmelon classified as watermelon).

### Task 3: Exploratory Data Analysis (EDA) & Key Findings
- **Correlation Insights**:
  - $P$ and $K$ exhibit a strong positive correlation ($r = 0.74$), characteristic of heavy feeder fruit orchards (Apple, Grapes).
  - Nitrogen strongly separates nitrogen-fixing legumes (Chickpea, Lentil $\approx 20-40$ kg/ha) from nitrogen-heavy cereal staples (Rice, Maize $\approx 80-120$ kg/ha).
  - Rainfall and Humidity act as strong environmental gates separating arid crops (Chickpea, Muskmelon) from tropical wet crops (Rice, Coconut, Jute).

### Task 4: Real-World Agronomic Constraint (Single-Nutrient Affordability)
- When a resource-constrained farmer can afford to test **only one soil nutrient**:
  - **Potassium ($K$)** is the single best predictor among soil attributes, achieving **29.77% accuracy** (1.8x higher than Nitrogen or Phosphorus alone), because extreme potassium demand acts as a binary separator for high-value orchards.
  - *Recommendation*: While single-nutrient testing provides a directional baseline, testing all 7 soil and climate parameters increases accuracy from 29.8% to **99.55%**.

---

## 🚀 How to Run the Web Application

**Requirements:** Python 3.9 or newer (https://www.python.org/downloads/ — tick *"Add python.exe to PATH"* on Windows) and an internet connection the first time (to download packages).

### Option A: 1-Click Startup (recommended)

| System | What to do |
|--------|------------|
| **Windows** | Unzip the folder, then double-click **`run.bat`** |
| **macOS / Linux** | Unzip, open a terminal in the folder, run `./run.sh` (or `bash run.sh`) |

The launcher creates a private virtual environment, installs the packages from `requirements.txt`, starts the server and opens your browser at **http://127.0.0.1:5000**. Keep the terminal window open while using the app; press `CTRL+C` to stop.

### Option B: Manual Command Line
```bash
cd Agri_Predit
python -m venv .venv
# Windows:      .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000 in your browser.

### Troubleshooting
- **"Python not found"** – install Python 3.9+ and make sure *Add to PATH* is ticked.
- **Package install fails** – the computer needs internet for the first run only.
- **Port 5000 already in use** – close the other program using it, or change `port=5000` at the bottom of `app.py`.
- **Message "Saved model not usable... rebuilding"** – normal and harmless: the app retrains the same Random Forest from `Crop_recommendation.csv` in a few seconds to match the installed scikit-learn version.
- Retraining / benchmark scripts (`train_and_evaluate.py`) additionally need `pip install -r requirements-training.txt` (adds XGBoost).
- A PDF report, PPT and all figures are in `reports/` and `report_images/` if the app cannot be run.
