#!/usr/bin/env bash
# Agri Predit launcher for macOS / Linux
cd "$(dirname "$0")" || exit 1

PY=$(command -v python3 || command -v python)
if [ -z "$PY" ]; then
  echo "[ERROR] Python 3 not found. Install it from https://www.python.org/downloads/"
  exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "[1/3] Creating virtual environment ..."
  "$PY" -m venv .venv || { echo "[ERROR] Could not create venv"; exit 1; }
fi

echo "[2/3] Checking required packages ..."
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt \
  || { echo "[ERROR] Package install failed (internet needed on first run)"; exit 1; }

echo "[3/3] Starting server at http://127.0.0.1:5000  (CTRL+C to stop)"
( sleep 3; (command -v open >/dev/null && open http://127.0.0.1:5000) || (command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:5000) ) >/dev/null 2>&1 &
.venv/bin/python app.py
