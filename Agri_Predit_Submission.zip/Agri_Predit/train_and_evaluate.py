import os
import json
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, f1_score, confusion_matrix
import xgboost as xgb

# Set working directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, "Crop_recommendation.csv")
MODELS_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(MODELS_DIR, exist_ok=True)

print("="*70)
print("AGRICULTURE CROP RECOMMENDATION SYSTEM: DATA SCIENCE PIPELINE")
print("="*70)

# 1. LOAD DATASET
df = pd.read_csv(CSV_PATH)
print(f"\n[+] Dataset Loaded Successfully: {df.shape[0]} rows, {df.shape[1]} columns")
print(f"Features: {list(df.columns[:-1])}")
print(f"Target: {df.columns[-1]} ({df['label'].nunique()} unique crops)")

# ==========================================
# TASK 1: DATA CLEANING & PREPROCESSING
# ==========================================
print("\n" + "="*50)
print("TASK 1: DATA CLEANING & PREPROCESSING")
print("="*50)

# Check missing values
missing_counts = df.isnull().sum()
print(f"Missing Values across all columns:\n{missing_counts}")

# Check duplicates
duplicate_count = df.duplicated().sum()
print(f"Duplicate rows detected: {duplicate_count}")

# Outlier analysis using IQR for soil and environmental attributes
outliers_summary = {}
numerical_cols = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
for col in numerical_cols:
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    col_outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)].shape[0]
    outliers_summary[col] = col_outliers
print(f"IQR Outliers Summary: {outliers_summary}")
print("Note: In agricultural datasets, high values in P, K, or rainfall represent crop-specific ecological niches (e.g., Grapes & Apples require high P & K; Rice requires heavy rainfall), which are natural domain variations rather than measurement errors.")

# ==========================================
# TASK 3: EXPLORATORY DATA ANALYSIS (EDA)
# ==========================================
print("\n" + "="*50)
print("TASK 3: EXPLORATORY DATA ANALYSIS (EDA)")
print("="*50)

# Statistical Summary
stats = df.describe().T[['mean', 'std', 'min', '50%', 'max']]
print("Statistical Summary of Attributes:")
print(stats.to_string())

# Correlation with soil & weather
corr = df[numerical_cols].corr()
print("\nCorrelation Matrix:")
print(corr.round(3).to_string())

# Calculate crop profiles (Mean, Min, Max for explainability in Web App)
crop_profiles = {}
for crop, group in df.groupby('label'):
    crop_profiles[crop] = {
        'N': {'mean': round(float(group['N'].mean()), 1), 'min': round(float(group['N'].min()), 1), 'max': round(float(group['N'].max()), 1)},
        'P': {'mean': round(float(group['P'].mean()), 1), 'min': round(float(group['P'].min()), 1), 'max': round(float(group['P'].max()), 1)},
        'K': {'mean': round(float(group['K'].mean()), 1), 'min': round(float(group['K'].min()), 1), 'max': round(float(group['K'].max()), 1)},
        'ph': {'mean': round(float(group['ph'].mean()), 2), 'min': round(float(group['ph'].min()), 2), 'max': round(float(group['ph'].max()), 2)},
        'temperature': {'mean': round(float(group['temperature'].mean()), 1), 'min': round(float(group['temperature'].min()), 1), 'max': round(float(group['temperature'].max()), 1)},
        'humidity': {'mean': round(float(group['humidity'].mean()), 1), 'min': round(float(group['humidity'].min()), 1), 'max': round(float(group['humidity'].max()), 1)},
        'rainfall': {'mean': round(float(group['rainfall'].mean()), 1), 'min': round(float(group['rainfall'].min()), 1), 'max': round(float(group['rainfall'].max()), 1)},
        'sample_count': len(group)
    }

profiles_path = os.path.join(MODELS_DIR, "crop_profiles.json")
with open(profiles_path, "w", encoding="utf-8") as f:
    json.dump(crop_profiles, f, indent=2)
print(f"\n[+] Saved crop profiles for all 22 crops to {profiles_path}")

# ==========================================
# TASK 4: REAL-WORLD CONSTRAINT EXPERIMENT (SINGLE NUTRIENT ANALYSIS)
# ==========================================
print("\n" + "="*50)
print("TASK 4: THE FARMER'S REAL-WORLD CONSTRAINT (ONE SOIL MEASUREMENT)")
print("="*50)
print("Constraint: The farmer can afford to test ONLY ONE soil parameter among {N, P, K, pH}.")
print("Objective: Discover which single soil attribute is the strongest predictor of the right crop.\n")

soil_features = ['N', 'P', 'K', 'ph']
X_full = df[numerical_cols]
y = df['label']

le = LabelEncoder()
y_encoded = le.fit_transform(y)
joblib.dump(le, os.path.join(MODELS_DIR, "label_encoder.joblib"))

# Train/test split (80/20 stratified)
X_train_full, X_test_full, y_train, y_test = train_test_split(
    X_full, y_encoded, test_size=0.20, random_state=42, stratify=y_encoded
)

single_feature_results = {}
single_feature_models = {}

for feat in soil_features:
    X_tr_feat = X_train_full[[feat]]
    X_te_feat = X_test_full[[feat]]
    
    # Train Random Forest on single feature
    clf_feat = RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42)
    clf_feat.fit(X_tr_feat, y_train)
    y_pred_feat = clf_feat.predict(X_te_feat)
    
    acc = accuracy_score(y_test, y_pred_feat)
    f1 = f1_score(y_test, y_pred_feat, average='weighted')
    
    single_feature_results[feat] = {
        'Test_Accuracy': round(acc * 100, 2),
        'Weighted_F1': round(f1, 4)
    }
    single_feature_models[feat] = clf_feat
    print(f"Model using ONLY [{feat:2s}]: Accuracy = {acc*100:6.2f}% | F1 Score = {f1:.4f}")

# Save all single feature models
joblib.dump(single_feature_models, os.path.join(MODELS_DIR, "single_feature_models.joblib"))

best_single_feat = max(single_feature_results, key=lambda k: single_feature_results[k]['Weighted_F1'])
print(f"\n>>> VERDICT: The single feature that best predicts the right crop is '{best_single_feat}' with {single_feature_results[best_single_feat]['Test_Accuracy']}% accuracy!")

# ==========================================
# TASK 2: FULL PREDICTIVE MODELING (ALL 7 ATTRIBUTES)
# ==========================================
print("\n" + "="*50)
print("TASK 2: PREDICTIVE MODELING (FULL ATTRIBUTES: SOIL + CLIMATE)")
print("="*50)

# Model 1: Random Forest Classifier
rf_clf = RandomForestClassifier(n_estimators=100, max_depth=12, random_state=42)
rf_clf.fit(X_train_full, y_train)
rf_preds = rf_clf.predict(X_test_full)
rf_train_acc = accuracy_score(y_train, rf_clf.predict(X_train_full))
rf_test_acc = accuracy_score(y_test, rf_preds)
rf_f1 = f1_score(y_test, rf_preds, average='weighted')

print("\n--- RANDOM FOREST CLASSIFIER ---")
print(f"Train Accuracy: {rf_train_acc*100:.2f}%")
print(f"Test Accuracy:  {rf_test_acc*100:.2f}%")
print(f"Weighted F1:    {rf_f1:.4f}")

# Feature importances in Random Forest
rf_importances = pd.Series(rf_clf.feature_importances_, index=numerical_cols).sort_values(ascending=False)
print("\nRandom Forest Feature Importances:")
for f, imp in rf_importances.items():
    print(f"  {f:12s}: {imp:.4f} ({imp*100:.1f}%)")

# Save Random Forest model
joblib.dump(rf_clf, os.path.join(MODELS_DIR, "crop_rf_model.joblib"))

# Model 2: XGBoost Classifier
xgb_clf = xgb.XGBClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=5,
    eval_metric='mlogloss',
    random_state=42
)
xgb_clf.fit(X_train_full, y_train)
xgb_preds = xgb_clf.predict(X_test_full)
xgb_train_acc = accuracy_score(y_train, xgb_clf.predict(X_train_full))
xgb_test_acc = accuracy_score(y_test, xgb_preds)
xgb_f1 = f1_score(y_test, xgb_preds, average='weighted')

print("\n--- XGBOOST CLASSIFIER ---")
print(f"Train Accuracy: {xgb_train_acc*100:.2f}%")
print(f"Test Accuracy:  {xgb_test_acc*100:.2f}%")
print(f"Weighted F1:    {xgb_f1:.4f}")

# Save XGBoost model
joblib.dump(xgb_clf, os.path.join(MODELS_DIR, "crop_xgb_model.joblib"))

# Model Comparison Summary
comparison_df = pd.DataFrame({
    'Model': ['Random Forest', 'XGBoost'],
    'Train Accuracy (%)': [round(rf_train_acc*100, 2), round(xgb_train_acc*100, 2)],
    'Test Accuracy (%)': [round(rf_test_acc*100, 2), round(xgb_test_acc*100, 2)],
    'Weighted F1 Score': [round(rf_f1, 4), round(xgb_f1, 4)]
})
print("\n" + "="*50)
print("MODEL COMPARISON SUMMARY")
print("="*50)
print(comparison_df.to_string(index=False))

# Detailed Classification Report for Best Model (Random Forest)
target_names = le.classes_
print("\nDetailed Classification Report (Random Forest):")
print(classification_report(y_test, rf_preds, target_names=target_names))

# Save summary metrics to json for frontend/docs
metrics_summary = {
    'single_feature_results': single_feature_results,
    'best_single_feature': best_single_feat,
    'full_model_results': {
        'Random_Forest': {
            'train_accuracy': round(rf_train_acc * 100, 2),
            'test_accuracy': round(rf_test_acc * 100, 2),
            'f1_score': round(rf_f1, 4),
            'feature_importances': {k: round(float(v), 4) for k, v in rf_importances.items()}
        },
        'XGBoost': {
            'train_accuracy': round(xgb_train_acc * 100, 2),
            'test_accuracy': round(xgb_test_acc * 100, 2),
            'f1_score': round(xgb_f1, 4)
        }
    }
}

with open(os.path.join(MODELS_DIR, "model_metrics.json"), "w", encoding="utf-8") as f:
    json.dump(metrics_summary, f, indent=2)

print("\n[+] All models, label encoders, crop profiles, and metric logs successfully generated and saved to models/ directory!")
