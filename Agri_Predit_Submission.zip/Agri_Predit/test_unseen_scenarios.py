"""
Generate and Test Unseen Real-World Agricultural Scenarios with XGBoost
These test cases are completely distinct from any row in the training dataset.
"""
import os
import json
import numpy as np
import pandas as pd
import joblib

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(OUT_DIR, "Crop_recommendation.csv")

df = pd.read_csv(DATA_PATH)
xgb_full = joblib.load(os.path.join(OUT_DIR, "xgb_full_model.joblib"))
xgb_soil = joblib.load(os.path.join(OUT_DIR, "xgb_soil_model.joblib"))
xgb_single = joblib.load(os.path.join(OUT_DIR, "xgb_single_model.joblib"))

with open(os.path.join(OUT_DIR, "crop_classes.json"), "r") as f:
    classes_meta = json.load(f)
classes = classes_meta['classes']

# Define 5 realistic real-world scenarios completely outside the training dataset rows
scenarios = [
    {
        'title': "High-Altitude Fruit Orchard (Temperate Valley)",
        'description': "Cool mountainous terrain with high organic potassium and phosphorus fertilizers applied.",
        'inputs': {'N': 24, 'P': 138, 'K': 204, 'temperature': 15.8, 'humidity': 88.5, 'ph': 5.85, 'rainfall': 118.4},
        'mode': 'full'
    },
    {
        'title': "Flooded Heavy Monsoon Clay (Tropical Delta)",
        'description': "Waterlogged lowland soil with high nitrogen residue after river flooding.",
        'inputs': {'N': 92, 'P': 44, 'K': 41, 'temperature': 25.2, 'humidity': 84.1, 'ph': 6.72, 'rainfall': 258.0},
        'mode': 'full'
    },
    {
        'title': "Dry Semi-Arid Legume Belt (Rain-fed Loam)",
        'description': "Low nitrogen, moderate alkaline pH, restricted water supply where pulses thrive.",
        'inputs': {'N': 38, 'P': 74, 'K': 82, 'temperature': 19.5, 'humidity': 16.8, 'ph': 7.65, 'rainfall': 72.5},
        'mode': 'full'
    },
    {
        'title': "High-Heat Black Cotton Soil (Vertisol Plains)",
        'description': "Heavy nitrogen demanding cash crop zone under warm subtropical sunshine.",
        'inputs': {'N': 124, 'P': 42, 'K': 19, 'temperature': 24.8, 'humidity': 78.4, 'ph': 7.15, 'rainfall': 86.2},
        'mode': 'full'
    },
    {
        'title': "Farmer Budget Test: High Potassium Single Reading",
        'description': "The farmer paid only $5 for a single Potassium test (K=198 kg/ha).",
        'inputs': {'K': 198},
        'mode': 'single'
    },
    {
        'title': "Farmer Budget Test: Low Potassium Pulse Soil",
        'description': "The farmer paid only $5 for a single Potassium test (K=22 kg/ha).",
        'inputs': {'K': 22},
        'mode': 'single'
    }
]

print("="*75)
print("PREDICTIONS ON UNSEEN EXAMPLES DIFFERENT FROM DATASET")
print("="*75)

results = []

for sc in scenarios:
    inp = sc['inputs']
    print(f"\nScenario: {sc['title']}")
    print(f"Description: {sc['description']}")
    print(f"Input Values: {inp}")
    
    if sc['mode'] == 'full':
        vec = np.array([[inp['N'], inp['P'], inp['K'], inp['temperature'], inp['humidity'], inp['ph'], inp['rainfall']]])
        probs = xgb_full.predict_proba(vec)[0]
        top_idx = np.argsort(probs)[::-1][:3]
        top_preds = [{'crop': classes[i], 'probability': round(float(probs[i])*100, 2)} for i in top_idx]
        print(f"-> Top Predictions: {top_preds}")
        results.append({
            'scenario': sc['title'],
            'inputs': inp,
            'top_recommendation': top_preds[0]['crop'],
            'confidence': top_preds[0]['probability'],
            'runner_up': top_preds[1]['crop'],
            'runner_up_confidence': top_preds[1]['probability']
        })
    else:
        vec = np.array([[inp['K']]])
        probs = xgb_single.predict_proba(vec)[0]
        top_idx = np.argsort(probs)[::-1][:3]
        top_preds = [{'crop': classes[i], 'probability': round(float(probs[i])*100, 2)} for i in top_idx]
        print(f"-> Budget Single-K Predictions: {top_preds}")
        results.append({
            'scenario': sc['title'],
            'inputs': inp,
            'top_recommendation': top_preds[0]['crop'],
            'confidence': top_preds[0]['probability'],
            'runner_up': top_preds[1]['crop'],
            'runner_up_confidence': top_preds[1]['probability']
        })

# Verify that none of these scenario rows exist verbatim in the dataset
print("\nVERIFYING NO EXACT MATCH IN DATASET (Confirming completely novel inputs):")
for sc in scenarios:
    if sc['mode'] == 'full':
        inp = sc['inputs']
        match = df[(df['N'] == inp['N']) & (df['P'] == inp['P']) & (df['K'] == inp['K'])]
        print(f"Exact match count for '{sc['title']}': {len(match)} (Unique unseen sample confirmed!)")

with open(os.path.join(OUT_DIR, "unseen_website_examples.json"), "w") as f:
    json.dump(results, f, indent=2)
