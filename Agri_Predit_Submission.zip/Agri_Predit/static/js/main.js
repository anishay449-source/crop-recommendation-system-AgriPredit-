// Agri Predit - Modern Crop Recommendation & Analytics Frontend Controller

let radarChartInstance = null;
let featureChartInstance = null;
let cropEvalChartInstance = null;
let evaluationDataLoaded = false;

// Quick Farm Presets (Real-world scenarios distinct from single raw dataset rows)
const PRESETS = {
    rice: { N: 92, P: 48, K: 42, Ph: 6.80, Temp: 23.5, Hum: 82.5, Rain: 240.0 },
    apple: { N: 25, P: 135, K: 198, Ph: 5.90, Temp: 22.5, Hum: 92.0, Rain: 112.0 },
    cotton: { N: 125, P: 45, K: 20, Ph: 6.90, Temp: 24.2, Hum: 79.5, Rain: 82.0 },
    chickpea: { N: 38, P: 68, K: 80, Ph: 7.20, Temp: 19.2, Hum: 16.5, Rain: 80.0 },
    coffee: { N: 105, P: 28, K: 30, Ph: 6.80, Temp: 25.5, Hum: 58.0, Rain: 160.0 },
    watermelon: { N: 100, P: 18, K: 50, Ph: 6.40, Temp: 25.8, Hum: 85.0, Rain: 50.0 }
};

// Main Tab Navigation Switcher
function switchMainTab(tabName) {
    const tabPredictor = document.getElementById('tabPredictor');
    const tabAnalytics = document.getElementById('tabAnalytics');
    const buttons = document.querySelectorAll('.nav-tabs .tab-link');

    if (tabName === 'predictor') {
        tabPredictor.classList.add('active');
        tabAnalytics.classList.remove('active');
        buttons[0].classList.add('active');
        buttons[1].classList.remove('active');
    } else {
        tabPredictor.classList.remove('active');
        tabAnalytics.classList.add('active');
        buttons[0].classList.remove('active');
        buttons[1].classList.add('active');

        // Lazy-load analytics charts on first switch
        if (!evaluationDataLoaded) {
            loadEvaluationDashboard();
        }
    }
}

// Update and synchronize a feature across sliders, inputs, badges, and gauges
function updateFeature(key, val) {
    val = parseFloat(val);
    const slider = document.getElementById('slider' + key);
    const numInput = document.getElementById('input' + key);
    const badge = document.getElementById('badge' + key);

    if (slider) slider.value = val;
    if (numInput) numInput.value = val;

    if (key === 'N') {
        badge.innerText = val + " kg/ha";
        const status = val < 40 ? "Low (Legumes)" : (val <= 80 ? "Medium" : "High (Cereals)");
        document.getElementById('statusN').innerText = status;
    } 
    else if (key === 'P') {
        badge.innerText = val + " kg/ha";
        const status = val < 35 ? "Low" : (val <= 75 ? "Medium" : "High (Fruits)");
        document.getElementById('statusP').innerText = status;
    } 
    else if (key === 'K') {
        badge.innerText = val + " kg/ha";
        const status = val < 35 ? "Low" : (val <= 85 ? "Medium" : "High (Orchards)");
        document.getElementById('statusK').innerText = status;
    } 
    else if (key === 'Ph') {
        badge.innerText = val.toFixed(2) + " pH";
        // Calculate needle position on 3.5 to 9.9 scale
        const pct = Math.max(0, Math.min(100, ((val - 3.5) / (9.9 - 3.5)) * 100));
        const needle = document.getElementById('phNeedle');
        if (needle) needle.style.left = pct + "%";

        let desc = "Neutral (Balanced nutrient absorption)";
        if (val < 4.5) desc = "Strongly Acidic (Requires lime application)";
        else if (val < 5.5) desc = "Moderately Acidic (Tea/Coffee favorable)";
        else if (val < 6.5) desc = "Slightly Acidic (Optimal root uptake)";
        else if (val <= 7.5) desc = "Neutral (Ideal for most crops)";
        else if (val <= 8.5) desc = "Moderately Alkaline (Calcareous soil)";
        else desc = "Strongly Alkaline (Requires gypsum)";
        document.getElementById('phDescriptor').innerText = desc;
    } 
    else if (key === 'Temp') {
        badge.innerText = val.toFixed(1) + " °C";
        let desc = "Warm Vegetative Climate";
        if (val < 18) desc = "Cool Winter/Highland Zone (< 18°C)";
        else if (val <= 28) desc = "Warm Moderate Vegetative Season";
        else desc = "High Tropical Heat (> 28°C)";
        document.getElementById('tempDescriptor').innerText = `${desc} (${val.toFixed(1)}°C)`;
    } 
    else if (key === 'Hum') {
        badge.innerText = val.toFixed(1) + " %";
        // Needle on 14% to 100% scale
        const pct = Math.max(0, Math.min(100, ((val - 14) / (100 - 14)) * 100));
        const needle = document.getElementById('humNeedle');
        if (needle) needle.style.left = pct + "%";

        let desc = "Humid Zone";
        if (val < 35) desc = "Very Arid / Dry Atmosphere";
        else if (val < 65) desc = "Moderate Relative Humidity";
        else if (val < 85) desc = "High Tropical Humidity";
        else desc = "Saturated Monsoon Climate";
        document.getElementById('humDescriptor').innerText = `${desc} (${val.toFixed(1)}%)`;
    } 
    else if (key === 'Rain') {
        badge.innerText = val.toFixed(1) + " mm";
        // Needle on 20 mm to 300 mm scale
        const pct = Math.max(0, Math.min(100, ((val - 20) / (300 - 20)) * 100));
        const needle = document.getElementById('rainNeedle');
        if (needle) needle.style.left = pct + "%";

        let desc = "Moderate Precipitation";
        if (val < 60) desc = "Arid / Deficit Irrigation Zone";
        else if (val < 130) desc = "Moderate Rainfall Zone";
        else if (val < 200) desc = "Heavy Rainfall Zone";
        else desc = "Wetland Monsoon Zone";
        document.getElementById('rainDescriptor').innerText = `${desc} (${val.toFixed(1)} mm)`;
    }
}

// Load Preset Farm Scenarios
function loadPreset(presetKey) {
    const p = PRESETS[presetKey];
    if (!p) return;

    updateFeature('N', p.N);
    updateFeature('P', p.P);
    updateFeature('K', p.K);
    updateFeature('Ph', p.Ph);
    updateFeature('Temp', p.Temp);
    updateFeature('Hum', p.Hum);
    updateFeature('Rain', p.Rain);

    // Auto submit to update the prediction and radar
    handleFormSubmit(new Event('submit'));
}

// Form Submit Handler
async function handleFormSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();

    const payload = {
        N: parseFloat(document.getElementById('inputN').value),
        P: parseFloat(document.getElementById('inputP').value),
        K: parseFloat(document.getElementById('inputK').value),
        ph: parseFloat(document.getElementById('inputPh').value),
        temperature: parseFloat(document.getElementById('inputTemp').value),
        humidity: parseFloat(document.getElementById('inputHum').value),
        rainfall: parseFloat(document.getElementById('inputRain').value)
    };

    const btn = document.getElementById('btnSubmit');
    const origHTML = btn.innerHTML;
    btn.innerHTML = "<span>⏳ Analyzing Field Diagnostics (Random Forest)...</span>";
    btn.disabled = true;

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.status === 'success') {
            renderPredictionResults(data);
        } else {
            alert("Error in diagnosis: " + data.message);
        }
    } catch (err) {
        console.error(err);
        alert("Failed to communicate with recommendation engine. Verify backend is running.");
    } finally {
        btn.innerHTML = origHTML;
        btn.disabled = false;
    }
}

// Render Prediction Results & Radar Chart
function renderPredictionResults(data) {
    document.getElementById('idleState').classList.add('hidden');
    document.getElementById('resultsContainer').classList.remove('hidden');

    // Hero Crop Card
    document.getElementById('resAvatar').innerText = data.icon;
    document.getElementById('resTitle').innerText = data.recommended_crop.toUpperCase();
    document.getElementById('resCategory').innerText = data.category + " Crop";
    document.getElementById('resConfidenceVal').innerText = data.confidence + "%";
    document.getElementById('resConfidenceBar').style.width = data.confidence + "%";
    document.getElementById('resAdviceText').innerText = data.farming_advice;

    // Render Radar Fingerprint Chart
    renderRadarChart(data.radar_comparison || data.radar_data);

    // Top 3 Candidate Crops Breakdown
    const top3Grid = document.getElementById('resTop3Grid');
    top3Grid.innerHTML = '';
    data.top3_crops.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'top3-item' + (index === 0 ? ' top3-winner' : '');
        card.innerHTML = `
            <span class="top3-icon">${item.icon}</span>
            <div class="top3-name-col">
                <strong>#${index + 1} ${item.crop.toUpperCase()}</strong>
                <small>${item.category} Crop</small>
            </div>
            <span class="top3-pct">${item.probability}%</span>
        `;
        top3Grid.appendChild(card);
    });

    // Scientific Benchmarks Table
    const tbody = document.getElementById('benchmarkTbody');
    tbody.innerHTML = '';

    const labelMap = {
        N: "Nitrogen (N) [kg/ha]",
        P: "Phosphorus (P) [kg/ha]",
        K: "Potassium (K) [kg/ha]",
        ph: "Soil Reaction (pH)",
        temperature: "Temperature (°C)",
        humidity: "Relative Humidity (%)",
        rainfall: "Annual Rainfall (mm)"
    };

    for (const [attr, stats] of Object.entries(data.benchmarks)) {
        const tr = document.createElement('tr');
        const isOptimal = stats.status === 'Optimal Match';
        const badgeClass = isOptimal ? 'status-optimal' : 'status-warning';

        tr.innerHTML = `
            <td><strong>${labelMap[attr] || attr}</strong></td>
            <td><strong class="highlight-val">${stats.user_value}</strong></td>
            <td>${stats.optimal_min} – ${stats.optimal_max}</td>
            <td>${stats.optimal_mean}</td>
            <td><span class="${badgeClass}">${stats.status}</span></td>
        `;
        tbody.appendChild(tr);
    }

    if (window.innerWidth <= 1024) {
        document.getElementById('resultsArea').scrollIntoView({ behavior: 'smooth' });
    }
}

// Render / Update Chart.js Radar Chart
function renderRadarChart(radarData) {
    const ctx = document.getElementById('radarChart').getContext('2d');

    const chartConfig = {
        type: 'radar',
        data: {
            labels: radarData.labels,
            datasets: [
                {
                    label: 'Your Field Diagnostic',
                    data: radarData.user_scores,
                    backgroundColor: 'rgba(16, 185, 129, 0.35)',
                    borderColor: '#10b981',
                    borderWidth: 2.5,
                    pointBackgroundColor: '#10b981',
                    pointBorderColor: '#ffffff',
                    pointHoverBackgroundColor: '#ffffff',
                    pointHoverBorderColor: '#10b981',
                    pointRadius: 4.5
                },
                {
                    label: 'Crop Ideal Benchmark',
                    data: radarData.crop_ideal_scores,
                    backgroundColor: 'rgba(56, 189, 248, 0.20)',
                    borderColor: '#38bdf8',
                    borderWidth: 2,
                    borderDash: [5, 4],
                    pointBackgroundColor: '#38bdf8',
                    pointBorderColor: '#ffffff',
                    pointHoverBackgroundColor: '#ffffff',
                    pointHoverBorderColor: '#38bdf8',
                    pointRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    angleLines: {
                        color: 'rgba(255, 255, 255, 0.12)'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.08)'
                    },
                    pointLabels: {
                        color: '#cbd5e1',
                        font: {
                            family: 'Plus Jakarta Sans',
                            size: 11.5,
                            weight: '600'
                        }
                    },
                    ticks: {
                        display: false,
                        min: 0,
                        max: 100,
                        stepSize: 20
                    },
                    suggestedMin: 0,
                    suggestedMax: 100
                }
            },
            plugins: {
                legend: {
                    display: false // Using custom HTML legend in panel header
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#34d399',
                    bodyColor: '#e2e8f0',
                    borderColor: 'rgba(16, 185, 129, 0.3)',
                    borderWidth: 1,
                    padding: 10,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw}% of max scale`;
                        }
                    }
                }
            }
        }
    };

    if (radarChartInstance) {
        radarChartInstance.data.labels = radarData.labels;
        radarChartInstance.data.datasets[0].data = radarData.user_scores;
        radarChartInstance.data.datasets[1].data = radarData.crop_ideal_scores;
        radarChartInstance.update();
    } else {
        radarChartInstance = new Chart(ctx, chartConfig);
    }
}

// Load Evaluation Metrics & Render Evaluation Graphs for Tab 2
async function loadEvaluationDashboard() {
    try {
        const response = await fetch('/api/metrics');
        const metrics = await response.json();
        evaluationDataLoaded = true;

        // Populate KPI Cards
        document.getElementById('kpiAccuracy').innerText = metrics.overall.accuracy.toFixed(2) + "%";
        document.getElementById('kpiF1').innerText = (metrics.overall.weighted_f1 / 100).toFixed(4);
        document.getElementById('kpiPrecision').innerText = metrics.overall.macro_precision.toFixed(2) + "%";
        document.getElementById('kpiRecall').innerText = metrics.overall.macro_recall.toFixed(2) + "%";

        // Render Graph 1: Feature Importance Horizontal Bar Chart
        renderFeatureImportanceChart(metrics.feature_importances);

        // Render Graph 2: Crop Precision & Recall Performance Chart
        renderCropPerformanceChart(metrics.class_metrics);

    } catch (err) {
        console.error("Failed to load evaluation metrics:", err);
    }
}

// Render Feature Importance Horizontal Bar Chart
function renderFeatureImportanceChart(featureData) {
    const ctx = document.getElementById('featureImportanceChart').getContext('2d');

    const labels = featureData.map(f => f.feature);
    const values = featureData.map(f => f.importance);
    const colors = featureData.map(f => f.color || '#10b981');

    if (featureChartInstance) {
        featureChartInstance.destroy();
    }

    featureChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Relative Feature Importance (%)',
                data: values,
                backgroundColor: colors,
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.06)'
                    },
                    ticks: {
                        color: '#94a3b8',
                        callback: (v) => v + "%"
                    },
                    max: 28
                },
                y: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#e2e8f0',
                        font: {
                            family: 'Plus Jakarta Sans',
                            weight: '600'
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#38bdf8',
                    bodyColor: '#e2e8f0',
                    borderColor: 'rgba(56, 189, 248, 0.3)',
                    borderWidth: 1,
                    padding: 10,
                    callbacks: {
                        label: (ctx) => `Importance: ${ctx.raw}% Gini Decrease`
                    }
                }
            }
        }
    });
}

// Render Crop Categories Precision & Recall Chart
function renderCropPerformanceChart(classMetrics) {
    const ctx = document.getElementById('cropPerformanceChart').getContext('2d');

    // Select 12 key crops representing all categories
    const selectedCrops = [
        "rice", "maize", "chickpea", "kidneybeans", 
        "banana", "mango", "grapes", "apple", 
        "watermelon", "cotton", "jute", "coffee"
    ];

    const filtered = classMetrics.filter(c => selectedCrops.includes(c.crop.toLowerCase()));
    const labels = filtered.map(c => c.crop.charAt(0).toUpperCase() + c.crop.slice(1));
    const precisions = filtered.map(c => c.precision);
    const recalls = filtered.map(c => c.recall);

    if (cropEvalChartInstance) {
        cropEvalChartInstance.destroy();
    }

    cropEvalChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Precision (%)',
                    data: precisions,
                    backgroundColor: '#10b981',
                    borderRadius: 6,
                    borderSkipped: false
                },
                {
                    label: 'Recall (%)',
                    data: recalls,
                    backgroundColor: '#38bdf8',
                    borderRadius: 6,
                    borderSkipped: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#cbd5e1',
                        font: {
                            family: 'Plus Jakarta Sans',
                            weight: '600'
                        }
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.06)'
                    },
                    ticks: {
                        color: '#94a3b8',
                        callback: (v) => v + "%"
                    },
                    min: 80,
                    max: 105
                }
            },
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#cbd5e1',
                        font: {
                            family: 'Plus Jakarta Sans',
                            weight: '600'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#34d399',
                    bodyColor: '#e2e8f0',
                    borderColor: 'rgba(16, 185, 129, 0.3)',
                    borderWidth: 1,
                    padding: 10,
                    callbacks: {
                        label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}%`
                    }
                }
            }
        }
    });
}

// Initial setup on load
document.addEventListener('DOMContentLoaded', () => {
    updateFeature('N', 90);
    updateFeature('P', 42);
    updateFeature('K', 43);
    updateFeature('Ph', 6.50);
    updateFeature('Temp', 24.5);
    updateFeature('Hum', 82.0);
    updateFeature('Rain', 215.0);

    // Run first prediction automatically for immediate interactive display
    handleFormSubmit(new Event('submit'));
});
