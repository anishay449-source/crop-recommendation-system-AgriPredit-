"""
Train Dedicated Single-Parameter Models and Multi-Feature Models
Features trained individually:
1. 'N' only
2. 'P' only
3. 'K' only
4. 'ph' only
5. 'soil' (N, P, K, ph)
6. 'full' (N, P, K, temperature, humidity, ph, rainfall)

Saves both XGBoost and Scikit-Learn fallback models so it runs on ANY environment.
"""
import os
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
import joblib

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(OUT_DIR, "Crop_recommendation.csv")

df = pd.read_csv(DATA_PATH)
print(f"Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")

le = LabelEncoder()
df['label_encoded'] = le.fit_transform(df['label'])
classes = list(le.classes_)

# Optional XGBoost import
try:
    import xgboost as xgb
    HAS_XGB = True
    print("XGBoost library detected and will be used as primary engine.")
except ImportError:
    HAS_XGB = False
    print("XGBoost not detected; using Scikit-Learn Random Forest.")

X_train_df, X_test_df, y_train, y_test = train_test_split(
    df, df['label_encoded'], test_size=0.2, random_state=42, stratify=df['label_encoded']
)

models_meta = {}

# 1. Train Single-Parameter Models
single_params = ['N', 'P', 'K', 'ph']

for param in single_params:
    X_tr = X_train_df[[param]]
    X_te = X_test_df[[param]]
    
    # Train Random Forest (universal compatibility)
    rf = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
    rf.fit(X_tr, y_train)
    y_pred_rf = rf.predict(X_te)
    acc_rf = accuracy_score(y_test, y_pred_rf)
    f1_rf = f1_score(y_test, y_pred_rf, average='weighted')
    joblib.dump(rf, os.path.join(OUT_DIR, f"model_rf_{param}.joblib"))
    
    # Train XGBoost if available
    acc_xgb, f1_xgb = None, None
    if HAS_XGB:
        model_xgb = xgb.XGBClassifier(
            n_estimators=100, max_depth=5, learning_rate=0.08, random_state=42, eval_metric='mlogloss'
        )
        model_xgb.fit(X_tr, y_train)
        y_pred_xgb = model_xgb.predict(X_te)
        acc_xgb = float(accuracy_score(y_test, y_pred_xgb))
        f1_xgb = float(f1_score(y_test, y_pred_xgb, average='weighted'))
        joblib.dump(model_xgb, os.path.join(OUT_DIR, f"model_xgb_{param}.joblib"))
    
    best_acc = acc_xgb if HAS_XGB and acc_xgb is not None else float(acc_rf)
    best_f1 = f1_xgb if HAS_XGB and f1_xgb is not None else float(f1_rf)
    
    models_meta[f"single_{param}"] = {
        'feature': param,
        'features_list': [param],
        'accuracy': round(best_acc, 4),
        'f1_score': round(best_f1, 4),
        'description': f"Predict crop using ONLY {param}"
    }
    print(f"Single Feature '{param}' -> Accuracy: {best_acc*100:.2f}%, F1: {best_f1:.4f}")

# 2. Train 4 Soil Nutrients Model (N, P, K, ph)
soil_features = ['N', 'P', 'K', 'ph']
X_tr_soil = X_train_df[soil_features]
X_te_soil = X_test_df[soil_features]

rf_soil = RandomForestClassifier(n_estimators=120, max_depth=10, random_state=42)
rf_soil.fit(X_tr_soil, y_train)
acc_rf_soil = accuracy_score(y_test, rf_soil.predict(X_te_soil))
f1_rf_soil = f1_score(y_test, rf_soil.predict(X_te_soil), average='weighted')
joblib.dump(rf_soil, os.path.join(OUT_DIR, "model_rf_soil.joblib"))

acc_xgb_soil, f1_xgb_soil = None, None
if HAS_XGB:
    xgb_soil = xgb.XGBClassifier(n_estimators=150, max_depth=6, learning_rate=0.08, random_state=42, eval_metric='mlogloss')
    xgb_soil.fit(X_tr_soil, y_train)
    acc_xgb_soil = float(accuracy_score(y_test, xgb_soil.predict(X_te_soil)))
    f1_xgb_soil = float(f1_score(y_test, xgb_soil.predict(X_te_soil), average='weighted'))
    joblib.dump(xgb_soil, os.path.join(OUT_DIR, "model_xgb_soil.joblib"))

best_acc_soil = acc_xgb_soil if HAS_XGB and acc_xgb_soil is not None else float(acc_rf_soil)
best_f1_soil = f1_xgb_soil if HAS_XGB and f1_xgb_soil is not None else float(f1_rf_soil)
models_meta['soil_4'] = {
    'features_list': soil_features,
    'accuracy': round(best_acc_soil, 4),
    'f1_score': round(best_f1_soil, 4),
    'description': "Predict using all 4 Soil features (N, P, K, ph)"
}
print(f"4 Soil Features -> Accuracy: {best_acc_soil*100:.2f}%, F1: {best_f1_soil:.4f}")

# 3. Train Full 7 Dataset Features (N, P, K, temperature, humidity, ph, rainfall)
all_features = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
X_tr_full = X_train_df[all_features]
X_te_full = X_test_df[all_features]

rf_full = RandomForestClassifier(n_estimators=150, random_state=42)
rf_full.fit(X_tr_full, y_train)
acc_rf_full = accuracy_score(y_test, rf_full.predict(X_te_full))
f1_rf_full = f1_score(y_test, rf_full.predict(X_te_full), average='weighted')
joblib.dump(rf_full, os.path.join(OUT_DIR, "model_rf_full.joblib"))

acc_xgb_full, f1_xgb_full = None, None
if HAS_XGB:
    xgb_full = xgb.XGBClassifier(n_estimators=200, max_depth=5, learning_rate=0.05, random_state=42, eval_metric='mlogloss')
    xgb_full.fit(X_tr_full, y_train)
    acc_xgb_full = float(accuracy_score(y_test, xgb_full.predict(X_te_full)))
    f1_xgb_full = float(f1_score(y_test, xgb_full.predict(X_te_full), average='weighted'))
    joblib.dump(xgb_full, os.path.join(OUT_DIR, "model_xgb_full.joblib"))

best_acc_full = acc_xgb_full if HAS_XGB and acc_xgb_full is not None else float(acc_rf_full)
best_f1_full = f1_xgb_full if HAS_XGB and f1_xgb_full is not None else float(f1_rf_full)
models_meta['full_7'] = {
    'features_list': all_features,
    'accuracy': round(best_acc_full, 4),
    'f1_score': round(best_f1_full, 4),
    'description': "Predict using all 7 features in dataset (N, P, K, pH, Temp, Humidity, Rain)"
}
print(f"Full 7 Features -> Accuracy: {best_acc_full*100:.2f}%, F1: {best_f1_full:.4f}")

# 4. Generate crop agronomic profile statistics strictly from the dataset
crop_stats = {}
for crop in classes:
    sub = df[df['label'] == crop]
    crop_stats[crop] = {
        'N': {'mean': round(float(sub['N'].mean()), 1), 'min': float(sub['N'].min()), 'max': float(sub['N'].max())},
        'P': {'mean': round(float(sub['P'].mean()), 1), 'min': float(sub['P'].min()), 'max': float(sub['P'].max())},
        'K': {'mean': round(float(sub['K'].mean()), 1), 'min': float(sub['K'].min()), 'max': float(sub['K'].max())},
        'ph': {'mean': round(float(sub['ph'].mean()), 2), 'min': round(float(sub['ph'].min()), 2), 'max': round(float(sub['ph'].max()), 2)},
        'temperature': {'mean': round(float(sub['temperature'].mean()), 1), 'min': round(float(sub['temperature'].min()), 1), 'max': round(float(sub['temperature'].max()), 1)},
        'humidity': {'mean': round(float(sub['humidity'].mean()), 1), 'min': round(float(sub['humidity'].min()), 1), 'max': round(float(sub['humidity'].max()), 1)},
        'rainfall': {'mean': round(float(sub['rainfall'].mean()), 1), 'min': round(float(sub['rainfall'].min()), 1), 'max': round(float(sub['rainfall'].max()), 1)},
    }

export_meta = {
    'classes': classes,
    'models_meta': models_meta,
    'crop_stats': crop_stats,
    'has_xgboost': HAS_XGB
}

with open(os.path.join(OUT_DIR, "single_models_metrics.json"), "w") as f:
    json.dump(export_meta, f, indent=2)

print("\nAll dedicated single models and metrics saved successfully!")
