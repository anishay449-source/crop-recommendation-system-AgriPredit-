@echo off
setlocal
title Agri Predit - Crop Recommendation System
cd /d "%~dp0"

echo =====================================================================
echo   Agri Predit - Precision Agronomy and Predictive Modeling Studio
echo   Random Forest crop recommendation (99.55 percent test accuracy)
echo =====================================================================
echo.

REM ---- 1. Find a working Python (ignores the Microsoft Store placeholder) ----
set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY (
    python --version >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo [ERROR] Python 3 was not found on this computer.
    echo.
    echo   1. Download Python from https://www.python.org/downloads/
    echo   2. During installation, TICK "Add python.exe to PATH"
    echo   3. Double-click run.bat again.
    echo.
    pause
    exit /b 1
)

REM ---- 2. Create a private environment (first run only) ----
if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating virtual environment ...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
)

REM ---- 3. Install required packages (first run needs internet) ----
echo [2/3] Checking required packages ...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 goto :fail

REM ---- 4. Start the app and open the browser ----
echo [3/3] Starting server at http://127.0.0.1:5000
echo       Keep this window open. Press CTRL+C to stop.
echo.
start "" cmd /c "timeout /t 5 >nul & start http://127.0.0.1:5000"
".venv\Scripts\python.exe" app.py
pause
exit /b 0

:fail
echo.
echo [ERROR] Setup failed. Please check that this computer is connected to the
echo         internet (needed once to download the packages) and try again.
echo.
pause
exit /b 1
