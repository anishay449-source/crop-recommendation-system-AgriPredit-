import os
import json
import warnings
import numpy as np
import pandas as pd
import joblib
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")

FEATURE_COLS = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']


def _rebuild_model():
    """Retrain the production Random Forest from the bundled CSV.

    Uses the exact same settings as train_and_evaluate.py (80/20 stratified split,
    random_state=42, 100 trees, max_depth=12), so results match the saved model.
    Takes only a few seconds and guarantees compatibility with whichever
    scikit-learn version is installed on this computer.
    """
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder

    df = pd.read_csv(os.path.join(BASE_DIR, "Crop_recommendation.csv"))
    le = LabelEncoder()
    y = le.fit_transform(df["label"])
    X_train, _, y_train, _ = train_test_split(
        df[FEATURE_COLS], y, test_size=0.20, random_state=42, stratify=y
    )
    clf = RandomForestClassifier(n_estimators=100, max_depth=12, random_state=42)
    clf.fit(X_train, y_train)
    return clf, le


def _load_model():
    """Load the saved Random Forest (99.55% accuracy).

    Pickled scikit-learn models can break (or silently misbehave) when opened with
    a different scikit-learn version. If the saved model is not loadable here, fall
    back to rebuilding it from the dataset so the app always starts.
    """
    try:
        try:
            from sklearn.exceptions import InconsistentVersionWarning
        except ImportError:  # very old scikit-learn
            InconsistentVersionWarning = None
        with warnings.catch_warnings():
            if InconsistentVersionWarning is not None:
                warnings.simplefilter("error", InconsistentVersionWarning)
            model = joblib.load(os.path.join(MODELS_DIR, "crop_rf_model.joblib"))
            encoder = joblib.load(os.path.join(MODELS_DIR, "label_encoder.joblib"))
        # Sanity check that the loaded model really works
        model.predict(pd.DataFrame([[90, 42, 43, 21, 82, 6.5, 203]], columns=FEATURE_COLS))
        return model, encoder
    except Exception as exc:
        print(f"[info] Saved model not usable on this system ({type(exc).__name__}); "
              "rebuilding from Crop_recommendation.csv ...")
        return _rebuild_model()


rf_model, label_encoder = _load_model()

with open(os.path.join(MODELS_DIR, "crop_profiles.json"), "r", encoding="utf-8") as f:
    crop_profiles = json.load(f)

with open(os.path.join(MODELS_DIR, "rf_evaluation_metrics.json"), "r", encoding="utf-8") as f:
    eval_metrics = json.load(f)

CROP_DESCRIPTIONS = {
    "rice": {"category": "Cereal", "icon": "🌾", "advice": "Thrives in warm, highly humid climates with abundant rainfall (>200 mm) and clayey or loamy soils with high water retention."},
    "maize": {"category": "Cereal", "icon": "🌽", "advice": "Requires well-drained, fertile loamy soil rich in nitrogen and moderate rainfall (60-100 mm) during vegetative growth."},
    "chickpea": {"category": "Legume", "icon": "🌱", "advice": "Prefers cool dry conditions, low nitrogen, deep sandy-loam soils, and fixes its own atmospheric nitrogen."},
    "kidneybeans": {"category": "Legume", "icon": "🫘", "advice": "Grows best in mild temperatures with slightly acidic soil and moderate phosphorus availability."},
    "pigeonpeas": {"category": "Legume", "icon": "🌿", "advice": "Drought tolerant, excels in warm semiarid zones with deep well-drained soils and low nitrogen input."},
    "mothbeans": {"category": "Legume", "icon": "🌾", "advice": "Extremely drought-hardy legume suitable for arid sandy soils with minimal irrigation requirements (30-70 mm)."},
    "mungbean": {"category": "Legume", "icon": "🫘", "advice": "Short-duration pulse crop thriving in warm humid climates (80-90% humidity) and fertile, well-aerated loam."},
    "blackgram": {"category": "Legume", "icon": "🌱", "advice": "Suited for hot, humid climates with heavy loamy or black cotton soil holding adequate moisture."},
    "lentil": {"category": "Legume", "icon": "🥣", "advice": "Cool season pulse crop thriving in mild winter temperatures and neutral-to-alkaline loamy soils."},
    "pomegranate": {"category": "Fruit", "icon": "🍎", "advice": "Semi-arid fruit tree that relishes dry summers, well-drained calcareous soil, and moderate potassium."},
    "banana": {"category": "Fruit", "icon": "🍌", "advice": "Heavy feeder requiring rich organic matter, balanced N-P-K, warm temperatures, and abundant water."},
    "mango": {"category": "Fruit", "icon": "🥭", "advice": "Tropical tree crop needing a distinct dry period for flowering, deep alluvium soil, and warm sunshine."},
    "grapes": {"category": "Fruit", "icon": "🍇", "advice": "Requires high phosphorus (120-145) and potassium (195-205), warm dry ripening weather, and well-drained gravelly loam."},
    "watermelon": {"category": "Fruit", "icon": "🍉", "advice": "Warm-season vine requiring sandy loam, high sunshine, moderate nitrogen, and warm root temperatures."},
    "muskmelon": {"category": "Fruit", "icon": "🍈", "advice": "Prefers sandy riverbed soils, low rainfall (20-30 mm), and high potassium for natural sugar development."},
    "apple": {"category": "Fruit", "icon": "🍏", "advice": "Temperate tree crop requiring high chill hours, acidic well-aerated soil, and heavy potassium uptake (195-205)."},
    "orange": {"category": "Fruit", "icon": "🍊", "advice": "Subtropical citrus needing well-drained light loams, neutral to slightly alkaline pH (6.0-8.0), and regular watering."},
    "papaya": {"category": "Fruit", "icon": "🥭", "advice": "Fast-growing tropical plant needing porous, non-waterlogged soil, high temperatures (25-40°C), and balanced nutrients."},
    "coconut": {"category": "Plantation", "icon": "🥥", "advice": "Coastal palm thriving in high humidity (>90%), warm temperatures, saline or sandy soils, and high rainfall (130-225 mm)."},
    "cotton": {"category": "Fiber", "icon": "☁️", "advice": "Cash crop thriving in deep black soils (regur), warm summers, moderate rainfall (60-100 mm), and ample nitrogen."},
    "jute": {"category": "Fiber", "icon": "🎋", "advice": "Golden fiber crop needing warm monsoon climate, high relative humidity (70-90%), alluvial soil, and heavy rains (150-200 mm)."},
    "coffee": {"category": "Plantation", "icon": "☕", "advice": "Grows best in shaded hill slopes, rich organic acidic soils (pH 6.0-7.0), and well-distributed rainfall (115-200 mm)."}
}

def get_ph_descriptor(ph):
    if ph < 4.5: return "Strongly Acidic (Lime Needed)"
    if ph < 5.5: return "Moderately Acidic"
    if ph < 6.5: return "Slightly Acidic (Ideal for Fruits)"
    if ph <= 7.5: return "Neutral (Ideal for Most Crops)"
    if ph <= 8.5: return "Moderately Alkaline"
    return "Strongly Alkaline (Gypsum Needed)"

def get_humidity_descriptor(hum):
    if hum < 35: return "Arid Dry Air"
    if hum < 65: return "Moderate Moisture"
    if hum < 85: return "Humid Growing Zone"
    return "Very High Tropical Humidity"

def get_rainfall_descriptor(rain):
    if rain < 60: return "Arid / Deficit Irrigation"
    if rain < 130: return "Moderate Rainfall"
    if rain < 200: return "Heavy Rainfall Zone"
    return "Wetland Monsoon Zone"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/metrics")
def get_metrics():
    return jsonify(eval_metrics)

@app.route("/api/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json(force=True)
        N = float(data.get("N", 0))
        P = float(data.get("P", 0))
        K = float(data.get("K", 0))
        temperature = float(data.get("temperature", 25.0))
        humidity = float(data.get("humidity", 70.0))
        ph = float(data.get("ph", 6.5))
        rainfall = float(data.get("rainfall", 100.0))

        # Build feature DataFrame
        features_df = pd.DataFrame(
            [[N, P, K, temperature, humidity, ph, rainfall]], 
            columns=['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
        )
        
        # Predict with best Random Forest Classifier
        pred_idx = rf_model.predict(features_df)[0]
        pred_label = label_encoder.inverse_transform([pred_idx])[0]
        
        probabilities = rf_model.predict_proba(features_df)[0]
        top3_indices = np.argsort(probabilities)[::-1][:3]
        
        top3 = []
        for idx in top3_indices:
            crop_name = label_encoder.inverse_transform([idx])[0]
            prob_pct = round(float(probabilities[idx]) * 100, 1)
            top3.append({
                "crop": crop_name,
                "probability": prob_pct,
                "icon": CROP_DESCRIPTIONS.get(crop_name, {}).get("icon", "🌱"),
                "category": CROP_DESCRIPTIONS.get(crop_name, {}).get("category", "General")
            })

        # Calculate scientific benchmarks ("On what basis it predicts")
        profile = crop_profiles.get(pred_label, {})
        user_inputs = {
            "N": N, "P": P, "K": K, 
            "ph": ph, "temperature": temperature, 
            "humidity": humidity, "rainfall": rainfall
        }
        
        benchmarks = {}
        for param, val in user_inputs.items():
            param_stats = profile.get(param, {"min": 0, "max": 0, "mean": 0})
            is_optimal = param_stats["min"] <= val <= param_stats["max"]
            benchmarks[param] = {
                "user_value": val,
                "optimal_min": param_stats["min"],
                "optimal_max": param_stats["max"],
                "optimal_mean": param_stats["mean"],
                "status": "Optimal Match" if is_optimal else ("Below Range" if val < param_stats["min"] else "Above Range")
            }

        # Normalize 0-100 for interactive Radar Fingerprint comparison
        # Upper scaling bounds: N: 140, P: 145, K: 205, pH: 10, Temp: 45, Hum: 100, Rain: 300
        radar_norm = {
            "labels": ["Nitrogen", "Phosphorus", "Potassium", "Soil pH", "Temperature", "Humidity", "Rainfall"],
            "user_scores": [
                round(min(100, (N / 140) * 100), 1),
                round(min(100, (P / 145) * 100), 1),
                round(min(100, (K / 205) * 100), 1),
                round(min(100, (ph / 10.0) * 100), 1),
                round(min(100, (temperature / 45.0) * 100), 1),
                round(min(100, (humidity / 100.0) * 100), 1),
                round(min(100, (rainfall / 300.0) * 100), 1)
            ],
            "crop_ideal_scores": [
                round(min(100, (profile.get('N', {}).get('mean', 50) / 140) * 100), 1),
                round(min(100, (profile.get('P', {}).get('mean', 50) / 145) * 100), 1),
                round(min(100, (profile.get('K', {}).get('mean', 50) / 205) * 100), 1),
                round(min(100, (profile.get('ph', {}).get('mean', 6.5) / 10.0) * 100), 1),
                round(min(100, (profile.get('temperature', {}).get('mean', 25) / 45.0) * 100), 1),
                round(min(100, (profile.get('humidity', {}).get('mean', 70) / 100.0) * 100), 1),
                round(min(100, (profile.get('rainfall', {}).get('mean', 100) / 300.0) * 100), 1)
            ]
        }

        crop_info = CROP_DESCRIPTIONS.get(pred_label, {"category": "Crop", "icon": "🌱", "advice": "Standard agricultural practices recommended."})

        return jsonify({
            "status": "success",
            "model_used": "Random Forest Classifier (99.55% Test Accuracy)",
            "recommended_crop": pred_label,
            "confidence": top3[0]["probability"],
            "icon": crop_info["icon"],
            "category": crop_info["category"],
            "farming_advice": crop_info["advice"],
            "top3_crops": top3,
            "benchmarks": benchmarks,
            "radar_comparison": radar_norm,
            "radar_data": radar_norm,
            "descriptors": {
                "ph_status": get_ph_descriptor(ph),
                "humidity_status": get_humidity_descriptor(humidity),
                "rainfall_status": get_rainfall_descriptor(rainfall)
            }
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
