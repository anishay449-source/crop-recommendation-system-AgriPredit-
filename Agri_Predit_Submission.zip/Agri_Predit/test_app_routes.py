import sys
import os

project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_dir)

from app import app

client = app.test_client()

# 1. Test GET /
res_index = client.get('/')
assert res_index.status_code == 200, f"Index returned {res_index.status_code}"
assert b"Agri Predit" in res_index.data
assert b"radarChart" in res_index.data
assert b"featureImportanceChart" in res_index.data
print("✓ GET / route passed, HTML and canvas tags verified")

# 2. Test GET /api/metrics
res_metrics = client.get('/api/metrics')
assert res_metrics.status_code == 200
metrics_json = res_metrics.get_json()
assert "overall" in metrics_json
assert "feature_importances" in metrics_json
assert "class_metrics" in metrics_json
acc = metrics_json["overall"]["accuracy"]
feat_len = len(metrics_json["feature_importances"])
print(f"✓ GET /api/metrics passed: Accuracy = {acc}%, Total Features = {feat_len}")

# 3. Test POST /api/predict (Test Case: Rice)
payload_rice = {
    "N": 90, "P": 42, "K": 43,
    "temperature": 24.5, "humidity": 82.0,
    "ph": 6.5, "rainfall": 215.0
}
res_pred = client.post('/api/predict', json=payload_rice)
assert res_pred.status_code == 200
pred_json = res_pred.get_json()
assert pred_json["status"] == "success"
assert pred_json["recommended_crop"] == "rice"
assert "radar_comparison" in pred_json
assert len(pred_json["radar_comparison"]["labels"]) == 7
assert "benchmarks" in pred_json
crop = pred_json["recommended_crop"]
conf = pred_json["confidence"]
labels = pred_json["radar_comparison"]["labels"]
print(f"✓ POST /api/predict passed: Recommended Crop = {crop}, Confidence = {conf}%, Radar Labels = {labels}")

# 4. Test POST /api/predict (Test Case: Apple)
payload_apple = {
    "N": 25, "P": 135, "K": 198,
    "temperature": 22.5, "humidity": 92.0,
    "ph": 5.9, "rainfall": 112.0
}
res_apple = client.post('/api/predict', json=payload_apple)
apple_json = res_apple.get_json()
assert apple_json["recommended_crop"] == "apple"
print(f"✓ POST /api/predict passed for Apple: Confidence = {apple_json['confidence']}%, Category = {apple_json['category']}")

# 5. Test POST /api/predict (Test Case: Cotton)
payload_cotton = {
    "N": 125, "P": 45, "K": 20,
    "temperature": 24.2, "humidity": 79.5,
    "ph": 6.9, "rainfall": 82.0
}
res_cotton = client.post('/api/predict', json=payload_cotton)
cotton_json = res_cotton.get_json()
assert cotton_json["recommended_crop"] == "cotton"
print(f"✓ POST /api/predict passed for Cotton: Confidence = {cotton_json['confidence']}%, Category = {cotton_json['category']}")

print("\n>>> ALL BACKEND & API TESTS PASSED WITH 100% SUCCESS! <<<")
